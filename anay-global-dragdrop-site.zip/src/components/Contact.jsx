export default function Contact(){
return(<section style={{padding:"60px"}}>
<h2>Contact</h2>
<p>Email: info@anayglobal.com</p>
</section>)}