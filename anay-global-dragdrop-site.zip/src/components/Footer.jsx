export default function Footer(){
return(<footer style={{background:"#065f46",color:"white",padding:"20px",textAlign:"center"}}>
© 2026 Anay Global Pte. Ltd.
</footer>)}