export default function BackToTop(){
function scrollTop(){window.scrollTo({top:0,behavior:"smooth"})}
return(<button onClick={scrollTop} style={{position:"fixed",bottom:"20px",right:"20px"}}>↑</button>)
}