export default function Services(){
return(<section style={{padding:"60px"}}>
<h2>Services</h2>
<ul>
<li>CFO Consulting</li>
<li>Accounting</li>
<li>Financial Planning</li>
</ul>
</section>)}