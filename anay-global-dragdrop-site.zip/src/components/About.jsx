export default function About(){
return(<section style={{padding:"60px"}}>
<h2>About Us</h2>
<p>Anay Global provides professional financial consulting and accounting services.</p>
</section>)}