export default function Hero(){
return(<section style={{padding:"80px",textAlign:"center"}}>
<h1>Professional CFO Consulting</h1>
<p>Helping businesses grow with financial expertise.</p>
</section>)}