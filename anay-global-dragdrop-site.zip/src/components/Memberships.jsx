export default function Memberships(){
return(<section style={{padding:"60px"}}>
<h2>Memberships</h2>
<p>Professional financial associations.</p>
</section>)}