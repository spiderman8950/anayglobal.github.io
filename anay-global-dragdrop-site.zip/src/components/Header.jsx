export default function Header(){
return(<header style={{background:"#047857",color:"white",padding:"20px"}}>
<h2>Anay Global Pte. Ltd.</h2>
</header>)}