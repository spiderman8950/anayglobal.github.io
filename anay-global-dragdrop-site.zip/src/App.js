import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Memberships from "./components/Memberships";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import BackToTop from "./components/BackToTop";

export default function App(){
return(
<div>
<Header/>
<Hero/>
<About/>
<Services/>
<Memberships/>
<Contact/>
<Footer/>
<BackToTop/>
</div>
)}