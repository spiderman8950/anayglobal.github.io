module.exports = {
content:["./src/**/*.{js,jsx}","./public/index.html"],
theme:{extend:{colors:{primary:"#047857",dark:"#065f46",light:"#10b981"}}},
plugins:[]
};